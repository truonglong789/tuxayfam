package vn.truonglong.tuxayfam;

import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TuXayFam extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("TuXayFam");

    @Override
    public void onInitialize() {
        LOG.info("TuXayFam loaded.");
        Modules.get().add(new TuXayFamModule());
    }

    @Override
    public void onRegisterCategories() {
    }

    @Override
    public String getPackage() {
        return "vn.truonglong.tuxayfam";
    }
}
