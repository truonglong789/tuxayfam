# TuXayFam

Minecraft 1.21.11 Fabric + Meteor addon starter source.

## Build

Use Java 21 and run:

```bash
./gradlew build
```

The compiled jar will be placed in `build/libs/`.

## Current state

This is the initial source project. The module loads into Meteor and provides the TuXayFam module, but the full Litematica planner, A* navigation, temporary bridge logic, auto-eat, inventory selection, and automatic layer progression still need implementation and API verification.
